var table = document.getElementById("ptable");
document.getElementById("addpassenger").addEventListener("click", function () {

    var size = table.rows.length;
    if (size < 7) {
        // Create a <tr> element
        var tr = document.createElement('tr');

        // Create <td> elements and append them to the <tr> element
        var td1 = document.createElement('td');
        var label = document.createElement('label');
        label.setAttribute('for', '');
        label.setAttribute('name', 'pcount');
        label.textContent = "P" + size;
        td1.appendChild(label);
        tr.appendChild(td1);

        var td2 = document.createElement('td');
        var inputName = document.createElement('input');
        inputName.setAttribute('type', 'text');
        inputName.className = 'pstyle';
        inputName.id = 'pname';
        td2.appendChild(inputName);
        tr.appendChild(td2);

        var td3 = document.createElement('td');
        var selectGender = document.createElement('select');
        selectGender.name = 'gender';
        selectGender.id = 'gender';

        var optionSelect = document.createElement('option');
        optionSelect.value = 'select';
        optionSelect.textContent = '-- Select --';
        selectGender.appendChild(optionSelect);

        var optionMale = document.createElement('option');
        optionMale.value = 'male';
        optionMale.textContent = 'Male';
        selectGender.appendChild(optionMale);

        var optionFemale = document.createElement('option');
        optionFemale.value = 'female';
        optionFemale.textContent = 'Female';
        selectGender.appendChild(optionFemale);

        var optionTransgender = document.createElement('option');
        optionTransgender.value = 'Transgender';
        optionTransgender.textContent = 'Transgender';
        selectGender.appendChild(optionTransgender);

        td3.appendChild(selectGender);
        tr.appendChild(td3);

        var td4 = document.createElement('td');
        var inputText = document.createElement('input');
        inputText.setAttribute('type', 'text');
        inputText.className = 'pstyle';
        td4.appendChild(inputText);
        tr.appendChild(td4);

        var td5 = document.createElement('td');
        var button = document.createElement('button');
        button.textContent = '❌';
        button.onclick = function () {
            del(this); // Assuming there's a function named del() for deletion
        };
        td5.appendChild(button);
        tr.appendChild(td5);

        // Append the <tr> element to a table or another container
        table.appendChild(tr);
    }
    else {
        window.alert("Limit of adding passengers reached..!!");
    }
});

function del(button) {
    var row = button.parentNode.parentNode;
    table.removeChild(row);
}