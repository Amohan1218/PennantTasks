CREATE TABLE ms_trainlist (
    from_station VARCHAR(100),
    to_station VARCHAR(100),
    train_name VARCHAR(100)
);

INSERT INTO MS_trainlist (from_station, to_station, train_name)
VALUES
    ('VSKP', 'BZA', 'Simhadri Express'),
    ('VSKP', 'CCT', 'Vskp Nzb Special'),
    ('VSKP', 'TPTY', 'Tpty Bbs Express'),
    ('VSKP', 'RJY', 'Puri-Tirupati Express'),
    ('VSKP', 'NLR', 'Tiruchchirappalli SF Express'),
    ('VSKP', 'AKP', 'Lingampalli Janmabhoomi SF Express'),
    ('VSKP', 'VZM', 'Visakha Express');
	
select * from ms_trainlist;


CREATE TABLE ms_stations (
    stn_code VARCHAR(10) PRIMARY KEY,
    stn_name VARCHAR(100)
);
INSERT INTO ms_stations (stn_code, stn_name)
VALUES
    ('BZA', 'Vijayawada Junction'),
    ('CCT', 'Kakinada Town Junction'),
    ('TPTY', 'Tirupati Main'),
    ('RJY', 'Rajahmundry'),
    ('NLR', 'Nellore'),
    ('AKP', 'Anakapalle'),
	('VSKP', 'Vishakapatnam Junction')
    ('VZM', 'Vizianagaram Junction');

Select * from ms_stations;
