package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import models.URLParameterExtraction;

@WebServlet("/getResult")
public class BookingServlet extends HttpServlet{
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
		PrintWriter out = res.getWriter();
		
		String queryString = req.getQueryString();
		
		ArrayList<Object> AE = new ArrayList<>();
		
		
		try {
			AE.add(URLParameterExtraction.convert(queryString)); // sending url
			
			req.setAttribute("data", AE);
			
			RequestDispatcher rd = req.getRequestDispatcher("/ConfirmTicket.jsp");
			rd.forward(req, res);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
}