package models;

public class Ticket {
	String from, to, trainname, dateOfDeparture, PNR;
	double fare;
	
}