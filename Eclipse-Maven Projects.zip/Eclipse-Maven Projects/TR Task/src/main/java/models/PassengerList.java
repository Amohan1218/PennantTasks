package models;

import java.util.ArrayList;

public class PassengerList{
	static ArrayList<Passenger> P = new ArrayList<>();
	
	static ArrayList<Passenger> getData(){
		return P;
	}
	
	static  void addPassenger(Passenger q){
		P.add(q);
	}
}
