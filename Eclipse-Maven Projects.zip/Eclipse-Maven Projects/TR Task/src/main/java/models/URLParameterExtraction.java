package models;

import java.net.URL;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class URLParameterExtraction {
	public static ArrayList<Passenger> convert(String url) throws Exception {
		
		// Parse the URL
		URL parsedUrl = new URL(url);
		String queryString = parsedUrl.getQuery();

		// Split query string into individual parameter-value pairs
		String[] params = queryString.split("&");

		// Create a map to store parameters and values
		Map<String, String> paramMap = new HashMap<>();

		// Extract parameters and values and store them in the map
		for (String param : params) {
			String[] keyValue = param.split("=");
			String paramName = URLDecoder.decode(keyValue[0], "UTF-8");
			String paramValue = URLDecoder.decode(keyValue[1], "UTF-8");
			paramMap.put(paramName, paramValue);
		}

		// Print the extracted parameters and their values
		paramMap.forEach((param, value) -> System.out.println(param + ": " + value));

		String from = paramMap.get("from");
		String to = paramMap.get("to");
		String trainName = paramMap.get("trainslist");
		String classs = paramMap.get("class");
		String date = paramMap.get("date");
		paramMap.remove("from");
		paramMap.remove("to");
		paramMap.remove("trainslist");
		paramMap.remove("class");
		

		for (int i = 1; i <= 6; i++) {
			String namev = null, genderv = null, agev = null;
			
			String namek = "P" + i + "name";
			String genderk = "P" + i + "gender";
			String agek = "P" + i + "age";
			for(String s : paramMap.keySet()) {
				if(namek.equals(s)) {
					namev = paramMap.get(s);
				}
				if(genderk.equals(s)) {
					genderv = paramMap.get(s);
				}
				if(agek.equals(s)) {
					agev = paramMap.get(s);
				}
			}
			if(namev == null || genderv == null || agev == null)
				continue;
			else
				PassengerList.addPassenger(new Passenger(namev, genderv, agev));
		}
		return PassengerList.getData();
	}
}










